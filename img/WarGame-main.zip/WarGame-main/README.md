# WarGame
Card game: "WAR" now with ninja's!
Adding an option to enter player name.

## Home Page
<img src="https://user-images.githubusercontent.com/62396197/163382298-2c256ba3-5e77-43a9-906e-f01e23421fba.png" alt="home_page" width="400" height="200"/>

## Info Page
<img src="https://user-images.githubusercontent.com/62396197/163382299-2ebd7cae-922d-433e-89d9-33fab28f3038.png" alt="home_page" width="400" height="200"/>

## Game Play
<img src="https://user-images.githubusercontent.com/62396197/163382301-6f81f138-3b90-452e-8574-fa78db421df4.png" alt="game_page" width="400" height="200"/>


